const Common_1 = require("./out/src/Common");
var fs = require("fs");
var path = require("path");
var userPath = Common_1.getConfigDir();


function emptyDir(fpath) {
    const files = fs.readdirSync(fpath);
    files.forEach(file => {
        const filePath = `${fpath}/${file}`;
        const stats = fs.statSync(filePath);
        if (stats.isDirectory()) {
            emptyDir(filePath);
        } else {
            fs.unlinkSync(filePath);
            console.log(`删除${file}文件成功`);
        }
    });
}
var path = require("path");

function CrackGuuid(uuidFilePath) {
    var newGuidRandom = "0"; //Math.floor((Math.random()* 0xff)).toString(16);
    var content = fs.readFileSync(uuidFilePath, 'utf8');
    content = content.replace(new RegExp(`\.toLowerCase\\(\\)`,"gi"), `.toLowerCase()+'0'`);
    fs.writeFileSync(uuidFilePath, content);
}

var guuidPath2 = path.resolve("out/src/luavm/nodeMachine.js");
var guuidPath = path.resolve("out/src/luatool/ex/ApiUtils.js");

CrackGuuid(guuidPath);
CrackGuuid(guuidPath2);

emptyDir(userPath);